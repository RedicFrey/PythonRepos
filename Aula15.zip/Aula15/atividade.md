>>    Invoke-RestMethod http://127.0.0.1:5000/api/livros `
>>     -Method POST `
>>     -ContentType "application/json" `
>>     -Body '{"titulo": "A outra volta do parafuso", "autor": "Henry James", "ano": 1898}'

comando usado ^

[
  {
    "ano": 1949,
    "autor": "George Orwell",
    "data_criacao": "2026-07-29 09:01:56.160130",
    "id": 3,
    "titulo": "1984"
  },
  {
    "ano": 1898,
    "autor": "Henry James",
    "data_criacao": "2026-07-29 09:22:18.086330",
    "id": 11,
    "titulo": "A outra volta do parafuso"
  },
  {
    "ano": 1972,
    "autor": "Italo Calvino",
    "data_criacao": "2026-07-29 09:24:52.168616",
    "id": 12,
    "titulo": "As cidades invisiveis"
  },
  {
    "ano": 1899,
    "autor": "Machado de Assis",
    "data_criacao": "2026-07-29 09:01:56.160130",
    "id": 1,
    "titulo": "Dom Casmurro"
  },
  {
    "ano": 2015,
    "autor": "Pierce Brown",
    "data_criacao": "2026-07-29 09:16:09.803335",
    "id": 6,
    "titulo": "Golden Son"
  },
  {
    "ano": 2006,
    "autor": "Brandon Sanderson",
    "data_criacao": "2026-07-29 09:10:19.499126",
    "id": 4,
    "titulo": "Mistborn"
  },
  {
    "ano": 2006,
    "autor": "Brandon Sanderson",
    "data_criacao": "2026-07-29 09:17:59.828961",
    "id": 10,
    "titulo": "Mistborn: O heroi das eras"
  },
  {
    "ano": 2006,
    "autor": "Brandon Sanderson",
    "data_criacao": "2026-07-29 09:17:13.768051",
    "id": 8,
    "titulo": "Mistborn: O imperio final"
  },
  {
    "ano": 2006,
    "autor": "Brandon Sanderson",
    "data_criacao": "2026-07-29 09:17:41.078038",
    "id": 9,
    "titulo": "Mistborn: O poco da ascencao"
  },
  {
    "ano": 2016,
    "autor": "Pierce Brown",
    "data_criacao": "2026-07-29 09:16:33.821212",
    "id": 7,
    "titulo": "Morning Star"
  },
  {
    "ano": 1890,
    "autor": "Alu\u00edsio Azevedo",
    "data_criacao": "2026-07-29 09:01:56.160130",
    "id": 2,
    "titulo": "O Corti\u00e7o"
  },
  {
    "ano": 2007,
    "autor": "Patrick Rothfuss",
    "data_criacao": "2026-07-29 09:27:11.928210",
    "id": 13,
    "titulo": "O nome do vento"
  },
  {
    "ano": 2014,
    "autor": "Pierce Brown",
    "data_criacao": "2026-07-29 09:15:25.877831",
    "id": 5,
    "titulo": "Red Rising"
  }
]

_______________________________
2

PS H:\Python\Aula15> $resposta = Invoke-RestMethod http://127.0.0.1:5000/api/livros/1 `
>>    -Method PUT `
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"Cotemig","autor":"3A1","ano":2026}'                        
PS H:\Python\Aula15>


{
  "ano": 2026,
  "autor": "3A1",
  "data_criacao": "2026-07-29 09:01:56.160130",
  "id": 1,
  "titulo": "Cotemig"
}

_______________________________
3


PS H:\Python\Aula15> Invoke-RestMethod http://127.0.0.1:5000/api/livros/5 -Method DELETE

PS H:\Python\Aula15> Invoke-RestMethod http://127.0.0.1:5000/api/livros/6 -Method DELETE

PS H:\Python\Aula15> Invoke-RestMethod http://127.0.0.1:5000/api/livros/7 -Method DELETE